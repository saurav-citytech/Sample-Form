package com.app.sampleform.model;

import java.util.List;

class Section {
    String sectionHeader;
    List<Field> fields;

    class Field{
        String displayLabel,dataType,defaultValue,description;
        int code;
        boolean isRequired;
        List<Value> values;
    }

    class Value{
        String option,value;
    }
}
