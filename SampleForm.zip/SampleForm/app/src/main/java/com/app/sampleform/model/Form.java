package com.app.sampleform.model;

import java.util.List;

public class Form {
    List<Section> sectionList;
}
